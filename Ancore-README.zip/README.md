

# 📱 Ancore PairCode & QR Session Generator

A modern, dark-mode WhatsApp MD Pair Code & QR session generation portal powered by [Baileys](https://github.com/Corex24/XD-Baileys). Built for seamless deployments on **Render**.

---

## 📂 Project Structure

```
Ancore-pair/
│
├── public/                   # Static web portal files (HTML/CSS/JS)
│   ├── index.html
│   └── pair.html
│
├── server.js                 # API server for PairCode & QR session generation
│
├── package.json              # Project dependencies and scripts
│
├── ancore-qr-session.json    # Auth state for QR login sessions
│
├── ancore-pair-xxxxx.json    # Auth states for PairCode sessions by number
│
├── render.yaml               # Render deployment config
│
└── README.md                 # This documentation
```

---

## 📣 Quick Setup

1. **Clone your repo**

```bash
git clone https://github.com/Corex24/Ancore-pair.git
cd Ancore-pair
```

2. **Install dependencies**

```bash
npm install
```

3. **Start your server locally**

```bash
node server.js
```

4. **Deploy to Render**
- Connect your GitHub repo.
- Add `node server.js` as start command.
- Set your build & deploy environment to `Node.js`.
- Deploy and go live.

---

## 📦 Dependencies

- [baileys](https://github.com/Corex24/XD-Baileys.git) via GitHub install:
  ```json
  "dependencies": {
    "baileys": "github:Corex24/XD-Baileys"
  }
  ```

- express
- axios

Install all with:

```bash
npm install
```

---

## 🔗 Links

- Telegram Group: [Join Here](https://t.me/+UfO-wlwfOaM3NmE0)
- Telegram Contact: [@corex2410](https://t.me/corex2410)
- WhatsApp Channel: [Ancore Updates](https://whatsapp.com/channel/0029Vb6nHar2phHORBFhOn3p)
- Instagram: [corex.anthony](https://www.instagram.com/corex.anthony?igsh=MWw0cXNxaG5pN2xxag==)
- GitHub: [Corex24](https://github.com/Corex24)

---

## ⚡ Powered by Corex 💙

